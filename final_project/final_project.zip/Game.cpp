/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.cpp
 * Author: blanca
 * 
 * Created on 10 de abril de 2018, 12:18
 */

#include <SFML/Window/VideoMode.hpp>
#include <SFML/Window/WindowStyle.hpp>
#include <SFML/Window/Window.hpp>

#include "Game.h"
#include "Food.h"

Game* Game::pinstance=0;
Game* Game::instance(){
    if(pinstance==0){
        pinstance= new Game();
    }
    return pinstance;
    
}

Game::Game()
:window(sf::VideoMode(1290,720), 'Ye', sf::Style::Close | sf::Style::Titlebar){
    
}


Game::run(){
    
    while(window.isOpen()){
        draw();
    }
    
}


Game::draw(){
    
    prueba.draw();
    
}

Game::update(){
    
    
}
