/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Sprite.h
 * Author: blanca
 *
 * Created on 10 de abril de 2018, 11:51
 */

#ifndef SPRITE_H
#define SPRITE_H

class Sprite {
public:
    Sprite();
    Sprite(const Sprite& orig);
    virtual ~Sprite();
    
    //metodos
    
    setSpriteTexture();
    draw();
    
    
private:
    sf::Sprite sprite;
    sf::Texture texture;
    Game* g;
};

#endif /* SPRITE_H */

