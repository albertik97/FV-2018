/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Sprite.cpp
 * Author: blanca
 * 
 * Created on 10 de abril de 2018, 11:51
 */

#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <string>
#include <SFML/Graphics/RenderWindow.hpp>

#include "Sprite.h"
#include "Game.h"
#include <string>

Sprite::Sprite(){
   g= Game::instance();
}

Sprite::setSpriteTexture(std::string route){
    
    texture.loadFromFile();
    sprite.setTexture(texture);
   
}


Sprite::draw(){
    
    g->getWindow().draw(sprite);
        
}


Sprite::Sprite(const Sprite& orig) {
}

Sprite::~Sprite() {
}

