/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Food.h
 * Author: blanca
 *
 * Created on 10 de abril de 2018, 12:13
 */

#ifndef FOOD_H
#define FOOD_H

class Food {
public:
    Food();
    Food(const Food& orig);
    virtual ~Food();
    
    asignTexture();
    draw();
private:
    Sprite foodSprite;
};

#endif /* FOOD_H */

