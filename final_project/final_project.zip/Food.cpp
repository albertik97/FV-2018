/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Food.cpp
 * Author: blanca
 * 
 * Created on 10 de abril de 2018, 12:13
 */

#include "Food.h"
#include "Sprite.h"
#include "Resources.h"

Food::Food() {
}

Food::asignTexture(){
    
    foodSprite.setSpriteTexture(FoodFilepath);
}

Food::draw(){
    foodSprite.draw();
}

Food::Food(const Food& orig) {
}

Food::~Food() {
}

